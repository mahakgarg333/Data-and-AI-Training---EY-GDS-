from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import os
from dotenv import load_dotenv
import json
import csv
from datetime import datetime
import requests

load_dotenv()

app = FastAPI(title="TriageX API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Models
class TicketInput(BaseModel):
    title: str
    description: str
    ticket_id: Optional[str] = None


class TicketOutput(BaseModel):
    ticket_id: Optional[str]
    title: str
    description: str
    category: str
    priority: str
    urgency: str
    suggested_team: str
    confidence: str


class CorrectionInput(BaseModel):
    ticket_id: str
    title: str
    description: str
    predicted_category: str
    predicted_priority: str
    predicted_urgency: str
    predicted_team: str
    correct_category: str
    correct_priority: str
    correct_urgency: str
    correct_team: str


# Initialize LLM using OpenRouter with Mistral
def get_llm_response(prompt: str, user_message: str) -> str:
    """Get response from Mistral via OpenRouter API"""
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        raise ValueError("OPENROUTER_API_KEY not found in environment variables")

    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": "mistralai/mistral-7b-instruct",
        "messages": [
            {
                "role": "system",
                "content": prompt
            },
            {
                "role": "user",
                "content": user_message
            }
        ],
        "temperature": 0.3,
        "max_tokens": 500
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        result = response.json()
        return result['choices'][0]['message']['content']
    except Exception as e:
        print(f"API Error: {str(e)}")
        raise


# Enhanced Triage prompt with clearer instructions
SYSTEM_PROMPT = """You are an expert IT support ticket classification system. Your job is to carefully analyze tickets and provide accurate classification.

You must classify tickets into these exact categories:

CATEGORY options (choose the most appropriate):
- Hardware Issue (for physical equipment problems like laptops, printers, monitors, keyboards)
- Software Bug (for application crashes, errors, malfunctions)
- Network Problem (for WiFi, VPN, connectivity issues)
- Account Access (for general access issues, permissions)
- Password Reset (specifically for password-related issues)
- Performance Issue (for slowness, lag, resource problems)
- Security Incident (for phishing, suspicious activity, security threats)
- Feature Request (for new functionality requests)
- Configuration (for setup, settings, installation issues)
- Database Issue (for database-specific problems)
- Email Issue (for email-specific problems)
- Other (only if none of the above fit)

PRIORITY options (assess business impact):
- Critical (system completely down, blocking critical business operations, multiple users affected, revenue impact)
- High (major functionality broken, significant user impact, urgent business need)
- Medium (moderate impact, workarounds available, affects productivity)
- Low (minor inconvenience, cosmetic issues, enhancement requests)

URGENCY options (assess time sensitivity):
- Immediate (needs response within 1 hour, business-critical, security threat)
- High (needs response within 4 hours, important but not critical)
- Medium (needs response within 24 hours, standard priority)
- Low (can wait 48+ hours, routine requests)

SUGGESTED_TEAM options:
- Infrastructure Team (for servers, storage, backups, data centers)
- Application Support (for software applications, CRM, business tools)
- Network Team (for routers, switches, WiFi, VPN, connectivity)
- Security Team (for security incidents, antivirus, threats)
- Database Team (for database issues, queries, performance)
- Help Desk (for passwords, basic access, general support)
- DevOps Team (for deployments, CI/CD, API issues)

CONFIDENCE (how sure you are):
- High (very clear classification)
- Medium (somewhat clear)
- Low (unclear or ambiguous)

Analyze the ticket carefully and respond ONLY with valid JSON in this exact format:
{
    "category": "exact category from list",
    "priority": "exact priority from list",
    "urgency": "exact urgency from list",
    "suggested_team": "exact team from list",
    "confidence": "High, Medium, or Low"
}"""


def triage_ticket(title: str, description: str) -> dict:
    """Triage a single ticket using Mistral LLM"""
    try:
        user_message = f"""Analyze this support ticket:

Title: {title}
Description: {description}

Provide classification in JSON format only."""

        result = get_llm_response(SYSTEM_PROMPT, user_message)

        # Clean up the response
        result = result.strip()

        # Remove markdown code blocks if present
        if result.startswith("```json"):
            result = result[7:]
        elif result.startswith("```"):
            result = result[3:]
        if result.endswith("```"):
            result = result[:-3]
        result = result.strip()

        # Parse JSON
        parsed = json.loads(result)

        # Validate required fields
        required_fields = ["category", "priority", "urgency", "suggested_team", "confidence"]
        for field in required_fields:
            if field not in parsed:
                raise ValueError(f"Missing field: {field}")

        return parsed
    except json.JSONDecodeError as e:
        print(f"JSON Parse Error: {str(e)}")
        print(f"Raw response: {result}")
        # Return intelligent fallback based on keywords
        return fallback_classification(title, description)
    except Exception as e:
        print(f"Error in triage: {str(e)}")
        return fallback_classification(title, description)


def fallback_classification(title: str, description: str) -> dict:
    """Fallback classification using keyword analysis"""
    text = (title + " " + description).lower()

    # Determine category
    category = "Other"
    if any(word in text for word in ["server", "down", "crash", "outage", "not responding"]):
        category = "Software Bug"
        priority = "Critical"
        urgency = "Immediate"
        team = "Infrastructure Team"
    elif any(word in text for word in ["password", "reset", "forgot", "locked out"]):
        category = "Password Reset"
        priority = "High"
        urgency = "High"
        team = "Help Desk"
    elif any(word in text for word in ["phishing", "suspicious", "malware", "security", "hack"]):
        category = "Security Incident"
        priority = "Critical"
        urgency = "Immediate"
        team = "Security Team"
    elif any(word in text for word in ["vpn", "network", "wifi", "connection", "connectivity"]):
        category = "Network Problem"
        priority = "High"
        urgency = "High"
        team = "Network Team"
    elif any(word in text for word in ["laptop", "keyboard", "monitor", "printer", "hardware"]):
        category = "Hardware Issue"
        priority = "Medium"
        urgency = "Medium"
        team = "Help Desk"
    elif any(word in text for word in ["slow", "performance", "lag", "sluggish"]):
        category = "Performance Issue"
        priority = "Medium"
        urgency = "Medium"
        team = "Application Support"
    elif any(word in text for word in ["database", "query", "sql"]):
        category = "Database Issue"
        priority = "High"
        urgency = "High"
        team = "Database Team"
    elif any(word in text for word in ["email", "outlook", "mail"]):
        category = "Email Issue"
        priority = "Medium"
        urgency = "Medium"
        team = "Help Desk"
    elif any(word in text for word in ["access", "permission", "cannot access"]):
        category = "Account Access"
        priority = "High"
        urgency = "High"
        team = "Help Desk"
    elif any(word in text for word in ["feature", "request", "enhancement", "would like"]):
        category = "Feature Request"
        priority = "Low"
        urgency = "Low"
        team = "Application Support"
    else:
        priority = "Medium"
        urgency = "Medium"
        team = "Help Desk"

    return {
        "category": category,
        "priority": priority,
        "urgency": urgency,
        "suggested_team": team,
        "confidence": "Medium"
    }


def log_correction(correction_data: dict):
    """Log corrections for future fine-tuning"""
    log_file = "corrections_log.csv"
    file_exists = os.path.isfile(log_file)

    with open(log_file, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=[
            'timestamp', 'ticket_id', 'title', 'description',
            'predicted_category', 'predicted_priority', 'predicted_urgency', 'predicted_team',
            'correct_category', 'correct_priority', 'correct_urgency', 'correct_team'
        ])

        if not file_exists:
            writer.writeheader()

        correction_data['timestamp'] = datetime.now().isoformat()
        writer.writerow(correction_data)


# API Endpoints
@app.get("/")
def root():
    return {
        "message": "TriageX - Intelligent Ticket Routing Engine API",
        "version": "1.0.0",
        "endpoints": {
            "POST /triage_ticket": "Triage a single ticket",
            "POST /triage_batch": "Triage multiple tickets",
            "POST /log_correction": "Log admin corrections",
            "GET /health": "Health check"
        }
    }


@app.get("/health")
def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}


@app.post("/triage_ticket", response_model=TicketOutput)
def triage_single_ticket(ticket: TicketInput):
    """Triage a single ticket"""
    try:
        result = triage_ticket(ticket.title, ticket.description)

        return TicketOutput(
            ticket_id=ticket.ticket_id,
            title=ticket.title,
            description=ticket.description,
            category=result["category"],
            priority=result["priority"],
            urgency=result["urgency"],
            suggested_team=result["suggested_team"],
            confidence=result["confidence"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/triage_batch")
def triage_batch_tickets(tickets: List[TicketInput]):
    """Triage multiple tickets"""
    try:
        results = []
        for idx, ticket in enumerate(tickets):
            print(f"Processing ticket {idx + 1}/{len(tickets)}: {ticket.ticket_id}")
            result = triage_ticket(ticket.title, ticket.description)
            results.append({
                "ticket_id": ticket.ticket_id,
                "title": ticket.title,
                "description": ticket.description,
                **result
            })
        return {"results": results, "count": len(results)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/log_correction")
def log_admin_correction(correction: CorrectionInput):
    """Log corrections made by admin for future fine-tuning"""
    try:
        log_correction(correction.dict())
        return {
            "status": "success",
            "message": "Correction logged successfully",
            "ticket_id": correction.ticket_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)