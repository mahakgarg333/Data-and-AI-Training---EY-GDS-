import streamlit as st
import pandas as pd
import requests
import json
from datetime import datetime
import io

# Page config
st.set_page_config(
    page_title="TriageX - Intelligent Ticket Routing",
    page_icon="🎫",
    layout="wide"
)

# API configuration
API_URL = "http://localhost:8000"

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        text-align: center;
        color: #666;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if 'triaged_data' not in st.session_state:
    st.session_state.triaged_data = None

# Header
st.markdown('<div class="main-header">🎫 TriageX</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Intelligent Ticket Routing Engine</div>', unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.header("⚙️ Configuration")
    st.info(f"API Endpoint: {API_URL}")

    # Check API health
    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        if response.status_code == 200:
            st.success("✅ API Connected")
        else:
            st.error("❌ API Error")
    except:
        st.error("❌ API Offline - Please start backend.py")

    st.markdown("---")
    st.header("📊 About")
    st.markdown("""
    **TriageX** automatically classifies support tickets using AI:

    - **Category**: Type of issue
    - **Priority**: Importance level
    - **Urgency**: Response timeline
    - **Team**: Best suited team

    Upload CSV or enter single ticket to get started!
    """)

    st.markdown("---")
    st.header("🎯 Classification Info")
    st.markdown("""
    **Priority Levels:**
    - 🔴 Critical - System down
    - 🟠 High - Major impact
    - 🟡 Medium - Moderate impact
    - 🟢 Low - Minor issue

    **Response Times:**
    - ⚡ Immediate - 1 hour
    - 🔥 High - 4 hours
    - ⏰ Medium - 24 hours
    - 📅 Low - 48 hours
    """)

# Main content
tab1, tab2 = st.tabs(["📤 Upload & Triage", "🎯 Single Ticket"])

# Tab 1: Batch Upload
with tab1:
    st.header("Batch Ticket Triage")
    st.markdown("Upload a CSV file with columns: `ticket_id`, `title`, `description`")

    # Sample CSV download
    sample_data = pd.DataFrame({
        'ticket_id': ['TKT-001', 'TKT-002', 'TKT-003'],
        'title': ['Cannot login to system', 'Server is down', 'Need access to database'],
        'description': [
            'User reports unable to login after password change',
            'Production server not responding since 2 hours',
            'New developer needs read access to production database'
        ]
    })

    csv_buffer = io.StringIO()
    sample_data.to_csv(csv_buffer, index=False)
    st.download_button(
        label="📥 Download Sample CSV",
        data=csv_buffer.getvalue(),
        file_name="sample_tickets.csv",
        mime="text/csv"
    )

    uploaded_file = st.file_uploader("Choose a CSV file", type=['csv'])

    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)
        st.subheader("📋 Uploaded Tickets")
        st.dataframe(df, use_container_width=True)

        if st.button("🚀 Start Triaging", type="primary", use_container_width=True):
            progress_bar = st.progress(0)
            status_text = st.empty()

            tickets_list = []
            for idx, row in df.iterrows():
                tickets_list.append({
                    "ticket_id": str(row.get('ticket_id', f'TKT-{idx}')),
                    "title": str(row['title']),
                    "description": str(row['description'])
                })

            try:
                status_text.text("🔄 Connecting to AI engine...")
                response = requests.post(
                    f"{API_URL}/triage_batch",
                    json=tickets_list,
                    timeout=300  # Increased timeout for batch processing
                )

                if response.status_code == 200:
                    results = response.json()['results']
                    st.session_state.triaged_data = pd.DataFrame(results)
                    st.success(f"✅ Successfully triaged {len(results)} tickets!")
                    progress_bar.progress(100)
                    status_text.empty()
                else:
                    st.error(f"❌ Error: {response.text}")
                    status_text.empty()
            except requests.exceptions.Timeout:
                st.error("⏱️ Request timed out. Try with fewer tickets or check if backend is running.")
            except Exception as e:
                st.error(f"❌ Connection Error: {str(e)}")
                st.info("💡 Make sure backend.py is running on port 8000")

    # Display triaged results
    if st.session_state.triaged_data is not None:
        st.markdown("---")
        st.subheader("📊 Triaged Results")

        df_triaged = st.session_state.triaged_data

        # Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Tickets", len(df_triaged))
        with col2:
            critical_count = len(df_triaged[df_triaged['priority'] == 'Critical'])
            st.metric("Critical Priority", critical_count, delta=None, delta_color="off")
        with col3:
            immediate_count = len(df_triaged[df_triaged['urgency'] == 'Immediate'])
            st.metric("Immediate Urgency", immediate_count, delta=None, delta_color="off")
        with col4:
            high_conf = len(df_triaged[df_triaged['confidence'] == 'High'])
            st.metric("High Confidence", high_conf, delta=None, delta_color="off")

        # Filters
        st.subheader("🔍 Filters")
        col1, col2, col3 = st.columns(3)

        with col1:
            filter_team = st.multiselect(
                "Filter by Team",
                options=sorted(df_triaged['suggested_team'].unique()),
                default=[]
            )

        with col2:
            priority_order = ['Critical', 'High', 'Medium', 'Low']
            available_priorities = [p for p in priority_order if p in df_triaged['priority'].unique()]
            filter_priority = st.multiselect(
                "Filter by Priority",
                options=available_priorities,
                default=[]
            )

        with col3:
            filter_category = st.multiselect(
                "Filter by Category",
                options=sorted(df_triaged['category'].unique()),
                default=[]
            )

        # Apply filters
        filtered_df = df_triaged.copy()
        if filter_team:
            filtered_df = filtered_df[filtered_df['suggested_team'].isin(filter_team)]
        if filter_priority:
            filtered_df = filtered_df[filtered_df['priority'].isin(filter_priority)]
        if filter_category:
            filtered_df = filtered_df[filtered_df['category'].isin(filter_category)]

        # Display with color coding for priority
        st.dataframe(
            filtered_df,
            use_container_width=True,
            height=400,
            column_config={
                "priority": st.column_config.TextColumn(
                    "Priority",
                    help="Priority level of the ticket"
                ),
                "urgency": st.column_config.TextColumn(
                    "Urgency",
                    help="Response time urgency"
                ),
                "category": st.column_config.TextColumn(
                    "Category",
                    help="Issue category"
                ),
                "suggested_team": st.column_config.TextColumn(
                    "Suggested Team",
                    help="Best team to handle this ticket"
                )
            }
        )

        # Show distribution charts
        st.markdown("---")
        st.subheader("📈 Distribution Analysis")

        chart_col1, chart_col2, chart_col3 = st.columns(3)

        with chart_col1:
            st.markdown("**Priority Distribution**")
            priority_counts = filtered_df['priority'].value_counts()
            st.bar_chart(priority_counts)

        with chart_col2:
            st.markdown("**Category Distribution**")
            category_counts = filtered_df['category'].value_counts()
            st.bar_chart(category_counts)

        with chart_col3:
            st.markdown("**Team Distribution**")
            team_counts = filtered_df['suggested_team'].value_counts()
            st.bar_chart(team_counts)

        # Download results
        csv_output = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Triaged Results",
            data=csv_output,
            file_name=f"triaged_tickets_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            use_container_width=True
        )

# Tab 2: Single Ticket
with tab2:
    st.header("Single Ticket Triage")
    st.markdown("Enter ticket details below for instant AI-powered classification")

    with st.form("single_ticket_form"):
        ticket_id = st.text_input("Ticket ID (optional)", placeholder="e.g., TKT-12345")
        title = st.text_input("Ticket Title*", placeholder="e.g., Cannot access email")
        description = st.text_area(
            "Ticket Description*",
            placeholder="Provide detailed description of the issue...",
            height=150
        )

        col1, col2 = st.columns([3, 1])
        with col1:
            submitted = st.form_submit_button("🔍 Analyze Ticket", type="primary", use_container_width=True)
        with col2:
            clear = st.form_submit_button("🔄 Clear", use_container_width=True)

        if submitted:
            if not title or not description:
                st.error("⚠️ Please fill in both title and description")
            else:
                try:
                    with st.spinner("🤖 AI is analyzing your ticket..."):
                        response = requests.post(
                            f"{API_URL}/triage_ticket",
                            json={
                                "ticket_id": ticket_id if ticket_id else None,
                                "title": title,
                                "description": description
                            },
                            timeout=60
                        )

                        if response.status_code == 200:
                            result = response.json()

                            st.success("✅ Ticket Analyzed Successfully!")

                            # Display results in cards
                            col1, col2 = st.columns(2)

                            with col1:
                                st.markdown("### 📋 Ticket Details")
                                if result.get('ticket_id'):
                                    st.info(f"**ID:** {result['ticket_id']}")
                                st.info(f"**Title:** {result['title']}")
                                st.text_area("Description", result['description'], height=100, disabled=True,
                                             key="result_desc")

                            with col2:
                                st.markdown("### 🎯 Classification Results")

                                priority_colors = {
                                    'Critical': '🔴',
                                    'High': '🟠',
                                    'Medium': '🟡',
                                    'Low': '🟢'
                                }

                                urgency_colors = {
                                    'Immediate': '⚡',
                                    'High': '🔥',
                                    'Medium': '⏰',
                                    'Low': '📅'
                                }

                                # Create colored boxes for results
                                st.markdown(f"""
                                <div style='background-color: #f0f2f6; padding: 15px; border-radius: 5px; margin: 10px 0;'>
                                    <strong>Category:</strong> {result['category']}
                                </div>
                                <div style='background-color: #f0f2f6; padding: 15px; border-radius: 5px; margin: 10px 0;'>
                                    <strong>Priority:</strong> {priority_colors.get(result['priority'], '⚪')} {result['priority']}
                                </div>
                                <div style='background-color: #f0f2f6; padding: 15px; border-radius: 5px; margin: 10px 0;'>
                                    <strong>Urgency:</strong> {urgency_colors.get(result['urgency'], '⏰')} {result['urgency']}
                                </div>
                                <div style='background-color: #f0f2f6; padding: 15px; border-radius: 5px; margin: 10px 0;'>
                                    <strong>Suggested Team:</strong> {result['suggested_team']}
                                </div>
                                <div style='background-color: #f0f2f6; padding: 15px; border-radius: 5px; margin: 10px 0;'>
                                    <strong>Confidence:</strong> {result['confidence']}
                                </div>
                                """, unsafe_allow_html=True)

                                # Recommended actions
                                st.markdown("---")
                                st.markdown("**📌 Recommended Action:**")
                                if result['urgency'] == 'Immediate':
                                    st.warning("⚡ Immediate attention required - Respond within 1 hour")
                                elif result['urgency'] == 'High':
                                    st.info("🔥 High priority - Respond within 4 hours")
                                elif result['urgency'] == 'Medium':
                                    st.info("⏰ Medium priority - Respond within 24 hours")
                                else:
                                    st.success("📅 Low priority - Respond within 48 hours")
                        else:
                            st.error(f"❌ Error: {response.text}")
                except requests.exceptions.Timeout:
                    st.error("⏱️ Request timed out. Please check if backend is running.")
                except Exception as e:
                    st.error(f"❌ Connection Error: {str(e)}")
                    st.info("💡 Make sure backend.py is running on port 8000")

# Footer
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: #666;'>TriageX v1.0.0 | Powered by Mistral AI via OpenRouter</div>",
    unsafe_allow_html=True
)