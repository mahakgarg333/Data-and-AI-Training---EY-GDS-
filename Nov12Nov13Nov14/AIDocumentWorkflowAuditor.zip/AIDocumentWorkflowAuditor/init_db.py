# backend/init_db.py
from models import init_db, insert_sop, list_sops

def seed():
    init_db()
    # HR Leave Approval SOP
    insert_sop(
        department="HR",
        name="Leave Approval Standard",
        required_steps=[
            "Employee Submission",
            "Manager Approval",
            "HR Verification",
            "HR Final Approval"
        ],
        sla_days=7,
        notes="Manager must approve before HR processes"
    )

    # Finance Expense Claim SOP
    insert_sop(
        department="Finance",
        name="Expense Claim Standard",
        required_steps=[
            "Employee Submission",
            "Manager Approval",
            "Budget Check",
            "Finance Approval"
        ],
        sla_days=5,
        notes="Claims above threshold require Manager + Budget check"
    )

    # DevOps Deployment SOP
    insert_sop(
        department="DevOps",
        name="Deployment Standard",
        required_steps=[
            "Developer Code Commit",
            "Peer Review",
            "QA Testing",
            "Manager Approval",
            "Production Deployment"
        ],
        sla_days=None,
        notes="All deployments must have QA signoff and manager approval"
    )

    print("Seeded SOPs:")
    for s in list_sops():
        print(s)

if __name__ == "__main__":
    seed()
