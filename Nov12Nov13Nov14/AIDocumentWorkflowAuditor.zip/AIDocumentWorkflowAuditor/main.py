# backend/main.py
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import io

from models import init_db, list_sops, insert_sop, get_conn
from nlp_engine import parse_workflow
from compliance_checker import fetch_sop_by_department, check_compliance

app = FastAPI(title="AI Document Workflow Auditor")

# Allow CORS from Streamlit local
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    # init db if not exists
    init_db()

class AuditResponse(BaseModel):
    sop_name: str
    department: str
    required_steps: list
    detected_steps_count: int
    matches: list
    missing_steps: list
    sla_violations: Optional[str]
    compliance_score: float

@app.get("/sops")
def get_sops():
    return list_sops()

@app.post("/audit", response_model=AuditResponse)
async def audit_workflow(text: Optional[str] = Form(None), department: Optional[str] = Form(None), file: Optional[UploadFile] = File(None)):
    """
    Accepts:
    - text (raw workflow text)
    - department (HR, Finance, DevOps)
    - file (optional) - accepts plain text or small pdf (pdf parsing not implemented here)
    """
    content = ""
    if file:
        # only accept small text files for simplicity
        data = await file.read()
        try:
            content = data.decode('utf-8')
        except:
            # if pdf or other binary, attempt simple text fallback
            content = ""
    if text and text.strip():
        content = text if not content else content + "\n" + text

    if not content:
        return {
            "sop_name": "",
            "department": "",
            "required_steps": [],
            "detected_steps_count": 0,
            "matches": [],
            "missing_steps": [],
            "sla_violations": "No content provided.",
            "compliance_score": 0.0
        }

    parsed = parse_workflow(content)
    if not department:
        department = "HR"  # default or optionally detect; defaulting makes demo easier

    sop = fetch_sop_by_department(department)
    if not sop:
        return {
            "sop_name": "",
            "department": department,
            "required_steps": [],
            "detected_steps_count": len(parsed["steps"]),
            "matches": [],
            "missing_steps": [],
            "sla_violations": f"No SOP found for department {department}",
            "compliance_score": 0.0
        }

    report = check_compliance(parsed, sop)
    return report






