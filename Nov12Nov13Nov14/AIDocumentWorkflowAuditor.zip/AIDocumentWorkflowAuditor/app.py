# frontend/app.py
import streamlit as st
import requests
import json
from pathlib import Path

BACKEND_URL = "http://127.0.0.1:8000"

st.set_page_config(page_title="AI Document Workflow Auditor", layout="wide")

st.title("AI Document Workflow Auditor — Demo")
st.markdown("Upload a workflow document or paste text, choose department, and run an audit.")

# Sidebar: select department and show SOPs
st.sidebar.header("Options")
with st.spinner("Fetching SOPs..."):
    try:
        r = requests.get(BACKEND_URL + "/sops")
        sops = r.json()
    except Exception as e:
        sops = []
        st.sidebar.error("Cannot reach backend. Start the FastAPI server first.")

dept_options = sorted(list({s['department'] for s in sops})) if sops else ["HR", "Finance", "DevOps"]
department = st.sidebar.selectbox("Department (SOP)", dept_options)

uploaded_file = st.file_uploader("Upload a .txt (or paste below)", type=["txt"])
text_input = st.text_area("Or paste workflow text here", height=200)

col1, col2 = st.columns([1, 1])
with col1:
    st.write("Sample workflow examples:")
    if st.button("Load HR sample"):
        text_input = """Employee submits leave request to Manager.
Manager approves the leave.
HR verifies and finalizes approval within 5 days.
"""
        st.session_state['text_input'] = text_input
with col2:
    if st.button("Load Broken HR sample"):
        text_input = """Employee sends leave request directly to HR.
HR approves and forwards to Finance.
"""
        st.session_state['text_input'] = text_input

# keep text input synced with session state
if 'text_input' in st.session_state and st.session_state['text_input']:
    text_input = st.session_state['text_input']

st.write("---")
run = st.button("Run Audit")

if run:
    payload = {}
    files = None
    if uploaded_file:
        files = {"file": (uploaded_file.name, uploaded_file.getvalue())}
    if text_input and not uploaded_file:
        payload = {"text": text_input, "department": department}
        try:
            resp = requests.post(BACKEND_URL + "/audit", data=payload, timeout=30)
            report = resp.json()
        except Exception as e:
            st.error(f"Error contacting backend: {e}")
            report = None
    else:
        # send file + department
        try:
            if files:
                resp = requests.post(BACKEND_URL + "/audit", files=files, data={"department": department}, timeout=30)
                report = resp.json()
            else:
                st.warning("Provide text or upload file first.")
                report = None
        except Exception as e:
            st.error(f"Error contacting backend: {e}")
            report = None

    if report:
        st.success(f"Compliance Score: {report.get('compliance_score')}%")
        st.subheader("SOP: " + (report.get("sop_name") or "—"))
        st.write("Department:", report.get("department"))
        st.write("Required Steps:", report.get("required_steps"))
        st.write("Detected step count:", report.get("detected_steps_count"))
        st.write("SLA Check:", report.get("sla_violations"))

        st.subheader("Matches")
        for m in report.get("matches", []):
            st.write("- ✅", m.get("required"), "→", m.get("matched_text"))

        if report.get("missing_steps"):
            st.subheader("Missing Steps")
            for ms in report.get("missing_steps"):
                st.write("- ⚠️", ms)

        st.write("---")
        st.json(report)

