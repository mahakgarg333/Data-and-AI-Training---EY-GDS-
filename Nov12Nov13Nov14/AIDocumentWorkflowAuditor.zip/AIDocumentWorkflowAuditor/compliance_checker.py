# backend/compliance_checker.py
import json
from models import get_conn
from typing import Dict, List

def fetch_sop_by_department(department: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM sop_rules WHERE department = ?", (department,))
    rows = cur.fetchall()
    conn.close()
    if not rows:
        return None
    # for simplicity pick the first matching SOP
    row = rows[0]
    return {
        "id": row["id"],
        "department": row["department"],
        "name": row["name"],
        "required_steps": json.loads(row["required_steps_json"]),
        "sla_days": row["sla_days"],
        "notes": row["notes"]
    }

def fuzzy_match_step(req_step: str, extracted_steps: List[Dict]) -> Dict:
    """
    Try to find a best match for req_step inside extracted_steps.
    Returns dict with 'found': True/False, 'matched_text': ...
    """
    req = req_step.lower()
    for s in extracted_steps:
        norm = s["normalized"]
        if req in norm or any(word in norm for word in req.split()):
            return {"found": True, "matched_text": s["text"], "details": s}
    # try token overlap
    req_tokens = set(req.split())
    best = None
    best_overlap = 0
    for s in extracted_steps:
        tok = set(s["normalized"].split())
        overlap = len(req_tokens.intersection(tok))
        if overlap > best_overlap and overlap > 0:
            best_overlap = overlap
            best = s
    if best:
        return {"found": True, "matched_text": best["text"], "details": best}
    return {"found": False, "matched_text": None, "details": None}

def check_compliance(parsed_workflow: Dict, sop: Dict) -> Dict:
    """
    Returns compliance report
    """
    report = {
        "sop_name": sop["name"],
        "department": sop["department"],
        "required_steps": sop["required_steps"],
        "detected_steps_count": len(parsed_workflow["steps"]),
        "matches": [],
        "missing_steps": [],
        "sla_violations": None,
        "compliance_score": 0.0
    }

    matches = 0
    for req in sop["required_steps"]:
        m = fuzzy_match_step(req, parsed_workflow["steps"])
        if m["found"]:
            matches += 1
            report["matches"].append({"required": req, "matched_text": m["matched_text"], "ok": True})
        else:
            report["missing_steps"].append(req)

    # SLA check
    sop_sla = sop.get("sla_days")
    detected_sla = parsed_workflow.get("sla_days")
    if sop_sla is not None:
        if detected_sla is None:
            report["sla_violations"] = f"SLA not mentioned in document. Expected <= {sop_sla} days."
        else:
            if detected_sla <= sop_sla:
                report["sla_violations"] = f"SLA satisfied: {detected_sla} days <= {sop_sla} days."
            else:
                report["sla_violations"] = f"SLA violated: {detected_sla} days > {sop_sla} days."
    else:
        report["sla_violations"] = "No SLA requirement in SOP."

    # Score: simple percent of required steps present
    total = len(sop["required_steps"]) if sop["required_steps"] else 1
    score = matches / total * 100.0
    report["compliance_score"] = round(score, 2)
    return report
