# backend/nlp_engine.py
import re
import json
from typing import List, Dict
import spacy

# Load spaCy model once
nlp = spacy.load("en_core_web_sm")

# heuristic lists - expandable
ACTOR_KEYWORDS = ["manager", "hr", "finance", "employee", "dev", "qa", "qa team", "team lead", "approver"]
APPROVAL_KEYWORDS = ["approve", "approval", "approved", "signoff", "sign-off", "authorize", "authorized", "verify", "verification"]

def extract_sentences(text: str) -> List[str]:
    doc = nlp(text)
    sentences = [sent.text.strip() for sent in doc.sents]
    return sentences

def normalize_step_text(text: str) -> str:
    # small normalizations
    t = text.lower()
    t = re.sub(r"[^a-z0-9\s]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def extract_steps(text: str) -> List[str]:
    sentences = extract_sentences(text)
    steps = []
    # If text has bullet lines, split by newline as well
    if "\n" in text:
        for line in text.splitlines():
            if line.strip():
                steps.append(line.strip())
    else:
        steps = sentences
    # Further chunking: break sentences by '->', 'then', ';'
    expanded = []
    for s in steps:
        parts = re.split(r"->|then|;|, then |\/", s, flags=re.IGNORECASE)
        for p in parts:
            p = p.strip()
            if p:
                expanded.append(p)
    # normalize and deduplicate while preserving order
    seen = set()
    normalized = []
    for s in expanded:
        n = normalize_step_text(s)
        if n not in seen:
            seen.add(n)
            normalized.append(s)
    return normalized

def detect_actors(step_text: str) -> List[str]:
    s = step_text.lower()
    found = []
    for k in ACTOR_KEYWORDS:
        if k in s:
            found.append(k)
    return found

def detect_approval(step_text: str) -> bool:
    s = step_text.lower()
    for k in APPROVAL_KEYWORDS:
        if k in s:
            return True
    return False

def extract_sla_days(text: str):
    # find patterns like "SLA: 7 days", "within 5 days", "in 3 days"
    m = re.search(r"(\b(?:sla|within|in|respond|response).{0,10}?)(\d{1,3})\s*day", text.lower())
    if m:
        try:
            return int(m.group(2))
        except:
            return None
    # pattern "7 days" near word 'days' but be conservative
    m2 = re.search(r"(\d{1,3})\s+days", text.lower())
    if m2:
        return int(m2.group(1))
    return None

def parse_workflow(text: str) -> Dict:
    """
    Returns:
    {
      "raw_steps": [...],
      "steps": [ {"text": "...", "actors": [...], "approval": True/False} ],
      "sla_days": int or None
    }
    """
    raw_steps = extract_steps(text)
    steps = []
    for s in raw_steps:
        steps.append({
            "text": s,
            "normalized": normalize_step_text(s),
            "actors": detect_actors(s),
            "approval": detect_approval(s)
        })
    sla = extract_sla_days(text)
    return {
        "raw_steps": raw_steps,
        "steps": steps,
        "sla_days": sla
    }
