# backend/models.py
import sqlite3
import json
from pathlib import Path

DB_PATH = Path(__file__).parent / "sop_rules.db"

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sop_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        department TEXT NOT NULL,
        name TEXT NOT NULL,
        required_steps_json TEXT NOT NULL,
        sla_days INTEGER DEFAULT NULL,
        notes TEXT DEFAULT NULL
    )
    """)
    conn.commit()
    conn.close()

def insert_sop(department: str, name: str, required_steps: list, sla_days: int = None, notes: str = ""):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO sop_rules (department, name, required_steps_json, sla_days, notes) VALUES (?, ?, ?, ?, ?)",
        (department, name, json.dumps(required_steps), sla_days, notes)
    )
    conn.commit()
    conn.close()

def list_sops():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM sop_rules")
    rows = cur.fetchall()
    conn.close()
    result = []
    for r in rows:
        result.append({
            "id": r["id"],
            "department": r["department"],
            "name": r["name"],
            "required_steps": json.loads(r["required_steps_json"]),
            "sla_days": r["sla_days"],
            "notes": r["notes"]
        })
    return result
